# 👹 WICKED SOUL V3

A small personal WhatsApp bot with a private pairing-code dashboard and two commands (`menu`, `ping`).

## Before you deploy
- Use a hosting provider that supports Node.js 20+ and persistent storage.
- Set `DASHBOARD_PASSWORD` to a long, unique secret in the host's environment settings.
- Set `AUTH_DIR` to a directory on persistent storage, if your host requires it.
- Never commit `.env`, `auth_info/`, pairing codes, or WhatsApp credentials.
- Do not make the dashboard public without protecting it. This project checks a dashboard password on the pairing form, but you should still use HTTPS and restrict access if your host supports it.

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Change `DASHBOARD_PASSWORD` to a strong secret.
4. Run `npm install` then `npm start`.
5. Open `http://localhost:3000`.

## Pair your WhatsApp
1. Open the dashboard.
2. Enter your dashboard password and phone number with country code, digits only (Nigeria: `234` + number without the leading `0`).
3. Submit and follow the instructions displayed.
4. In WhatsApp, use Settings → Linked devices and follow the phone-number linking flow if available.

## Notes
- This is an unofficial WhatsApp Web integration using the community-maintained Baileys library, not an official WhatsApp product. Compatibility can change, and automation may risk account restrictions. Use it only with an account you control and follow WhatsApp's terms.
- Keep your dashboard private and protect the saved `auth_info` directory. Anyone with the session files may be able to access the WhatsApp account.
- The starter bot replies only to `menu` / `!menu` / `.menu` and `ping` / `!ping` / `.ping`.
- A running server is required; GitHub stores code but does not run the bot by itself.
