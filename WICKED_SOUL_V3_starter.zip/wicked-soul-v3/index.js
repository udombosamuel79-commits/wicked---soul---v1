import 'dotenv/config';
import express from 'express';
import pino from 'pino';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion
} from '@whiskeysockets/baileys';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(express.json({ limit: '10kb' }));

const PORT = Number(process.env.PORT || 3000);
const DASHBOARD_PASSWORD = process.env.DASHBOARD_PASSWORD;
const AUTH_DIR = path.resolve(process.env.AUTH_DIR || path.join(__dirname, 'auth_info'));

if (!DASHBOARD_PASSWORD || DASHBOARD_PASSWORD === 'change-this-to-a-long-random-password') {
  console.error('Set a strong DASHBOARD_PASSWORD environment variable before starting.');
  process.exit(1);
}

let sock = null;
let isConnected = false;
let connecting = false;
let lastMessage = 'Not connected yet';
let lastPairCode = '';
let startPromise = null;\nlet whatsappRegistered = false;

const page = (message = '') => `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>WICKED SOUL V3</title>
<style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#050807;color:#f5f7f6;font-family:system-ui,Arial,sans-serif}
.wrap{max-width:620px;margin:36px auto;padding:18px}.brand{font-size:clamp(26px,6vw,38px);font-weight:900;letter-spacing:-1px}
.brand span{color:#20d49a}.sub{color:#a7b4af;margin:8px 0 24px}.card{background:#101715;border:1px solid #263a33;border-radius:22px;padding:22px;margin:16px 0;box-shadow:0 10px 30px #0005}
label{display:block;color:#aebbb5;font-size:13px;font-weight:700;margin:15px 0 8px}input{width:100%;padding:15px;border:1px solid #34443d;border-radius:12px;background:#080d0b;color:white;font-size:16px}
button{width:100%;padding:15px;border:0;border-radius:13px;background:#16c991;color:#04120c;font-weight:800;font-size:16px;margin-top:15px}
.note{color:#9daaa4;font-size:13px;line-height:1.5}.status{color:#65e6b8;font-weight:700}.msg{background:#0a2219;padding:12px;border-radius:10px;color:#a9f5d9;margin:12px 0;overflow-wrap:anywhere}
</style></head><body><main class="wrap">
<div class="brand">👹 WICKED <span>SOUL V3</span></div><div class="sub">Personal WhatsApp bot dashboard</div>
${message ? `<div class="msg">${escapeHtml(message)}</div>` : ''}
<section class="card"><h2>Connect your WhatsApp</h2>
<p class="note">Enter your private dashboard password and WhatsApp number with country code. For Nigeria, use 234 followed by your number, without the first 0.</p>
<form method="post" action="/pair">
<label>Dashboard password</label><input type="password" name="password" required autocomplete="current-password">
<label>WhatsApp number (country code included)</label><input type="tel" name="phone" placeholder="2348012345678" pattern="[0-9]{8,15}" required>
<button type="submit">Generate pairing code</button></form></section>
<section class="card"><h3>Bot status</h3><p class="status">${isConnected ? 'Connected to WhatsApp' : connecting ? 'Connecting…' : 'Not connected'}</p>
<p class="note">Latest status: ${escapeHtml(lastMessage)}</p>
${lastPairCode ? `<p class="note">Latest pairing code (private):</p><div class="msg">${escapeHtml(lastPairCode)}</div>` : ''}
</section><p class="note">Keep this dashboard private. Never share your pairing code or saved session. This is an unofficial WhatsApp Web integration and may be affected by WhatsApp changes or restrictions.</p>
</main></body></html>`;

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

app.get('/', (_req, res) => res.type('html').send(page()));

async function startSocket() {
  if (startPromise) return startPromise;
  startPromise = (async () => {
    connecting = true;
    try {
      fs.mkdirSync(AUTH_DIR, { recursive: true });
      const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
      let version;
      whatsappRegistered = Boolean(state.creds.registered);
      try { ({ version } = await fetchLatestBaileysVersion()); } catch { version = undefined; }
      sock = makeWASocket({
        version,
        auth: state,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        browser: ['WICKED SOUL V3', 'Chrome', '1.0.0'],
        markOnlineOnConnect: false,
        syncFullHistory: false
      });
      sock.ev.on('creds.update', saveCreds);
      sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
        if (connection === 'open') {
          isConnected = true; connecting = false; whatsappRegistered = true; lastMessage = 'WhatsApp connection is open'; lastPairCode = '';
        } else if (connection === 'close') {
          isConnected = false; connecting = false;
          const code = lastDisconnect?.error?.output?.statusCode;
          lastMessage = `Connection closed${code ? ` (code ${code})` : ''}`;
          if (code !== DisconnectReason.loggedOut) {
            setTimeout(() => { startPromise = null; startSocket().catch(() => {}); }, 3000);
          } else {
            lastMessage = 'Logged out. Clear the saved session on your host and pair again.';
            startPromise = null;
          }
        }
      });
      sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        for (const m of messages) {
          if (!m.message || m.key.fromMe || m.key.remoteJid === 'status@broadcast') continue;
          const text = m.message.conversation || m.message.extendedTextMessage?.text || '';
          if (!text.trim()) continue;
          const cmd = text.trim().toLowerCase();
          if (cmd === 'menu' || cmd === '!menu' || cmd === '.menu') {
            await sock.sendMessage(m.key.remoteJid, { text:
              '👹 *WICKED SOUL V3*\\n\\nCommands:\\n• menu — show this menu\\n• ping — check the bot\\n\\nPersonal bot is online.' }, { quoted: m });
          } else if (cmd === 'ping' || cmd === '!ping' || cmd === '.ping') {
            await sock.sendMessage(m.key.remoteJid, { text: '🏓 WICKED SOUL V3 is online!' }, { quoted: m });
          }
        }
      });
    } catch (err) {
      connecting = false; startPromise = null;
      lastMessage = 'Could not start bot. Check server logs.';
      console.error('Bot startup error:', err?.message || err);
      throw err;
    }
  })();
  return startPromise;
}

app.post('/pair', async (req, res) => {
  const password = String(req.body.password || '');
  const phone = String(req.body.phone || '').replace(/\D/g, '');
  if (password !== DASHBOARD_PASSWORD) return res.status(401).type('html').send(page('Incorrect dashboard password.'));
  if (!/^[0-9]{8,15}$/.test(phone)) return res.status(400).type('html').send(page('Enter a valid phone number with country code.'));
  try {
    await startSocket();
    if (!whatsappRegistered) {
      // Allow the socket a brief moment to initialise before requesting a code.
      await new Promise(r => setTimeout(r, 1200));
      const code = await sock.requestPairingCode(phone);
      lastPairCode = code;
      lastMessage = 'Pairing code generated. Enter it in WhatsApp Linked devices.';
      return res.type('html').send(page(`Your pairing code is: ${code}. On WhatsApp, open Settings > Linked devices > Link a device, then choose linking with phone number if offered and enter the code. Keep it private.`));
    }
    return res.type('html').send(page('This server already has a registered WhatsApp session. Check the status below.'));
  } catch (err) {
    console.error('Pairing error:', err?.message || err);
    return res.status(500).type('html').send(page('Could not generate a code. Check the server logs and try again.'));
  }
});

app.get('/health', (_req, res) => res.json({ ok: true, connected: isConnected, status: lastMessage }));
app.listen(PORT, () => {
  console.log(`WICKED SOUL V3 dashboard listening on port ${PORT}`);
  // Restore an existing session after server restarts.
  if (fs.existsSync(AUTH_DIR) && fs.readdirSync(AUTH_DIR).length > 0) {
    startSocket().catch(() => {});
  }
});